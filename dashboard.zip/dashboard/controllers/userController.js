const { getUser } = require("../models/userModel")

exports.loginPage = (req,res,next)=>{
    res.render("login")
}

exports.dashboardPage = (req,res,next) => {
    res.render("dashboard")
}

exports.loginProcess = (req,res,next) => {
     const user = getUser(req.body.email)
     console.log(req.body);

     if(user !==null && user.password === req.body.password){
        res.redirect("/dashboard")
     }else if( user === null ){
        res.render("error",{
            message:"NO user exists"
        })
     }else{
        res.render("error",{
            message:"IN VALID CREDENTIALS"
        })
     }
}